﻿namespace HoangThong.MyProject.Configuration;

public static class AppSettingNames
{
    public const string UiTheme = "App.UiTheme";
}
