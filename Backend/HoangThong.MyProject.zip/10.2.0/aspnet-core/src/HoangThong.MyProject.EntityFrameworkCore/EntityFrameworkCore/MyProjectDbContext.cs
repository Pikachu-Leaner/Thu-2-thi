﻿using Abp.Zero.EntityFrameworkCore;
using HoangThong.MyProject.Authorization.Roles;
using HoangThong.MyProject.Authorization.Users;
using HoangThong.MyProject.MultiTenancy;
using Microsoft.EntityFrameworkCore;

namespace HoangThong.MyProject.EntityFrameworkCore;

public class MyProjectDbContext : AbpZeroDbContext<Tenant, Role, User, MyProjectDbContext>
{
    /* Define a DbSet for each entity of the application */

    public MyProjectDbContext(DbContextOptions<MyProjectDbContext> options)
        : base(options)
    {
    }
}
